package com.insurance.insuranceCompany.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.insuranceCompany.contract.InsurancePackageContract;
import com.insurance.insuranceCompany.contract.InsurancePackageServiceContract;
import com.insurance.insuranceCompany.model.Categories;
import com.insurance.insuranceCompany.model.DiseaseDetails;
import com.insurance.insuranceCompany.model.InsurancePackage;
import com.insurance.insuranceCompany.model.InsurancePackageCoveredDisease;

@Service
public class InsurancePackageService implements InsurancePackageServiceContract {
	@Autowired
	private  InsurancePackageContract insurancePackageDAO;

	@Override
	public List<InsurancePackage> getAllInsurancePackages() {
		return insurancePackageDAO.getAllInsurancePackages();
	}

	public List<InsurancePackageCoveredDisease> getCoveredDiseasesByPackageId(int packageId) {
		return insurancePackageDAO.getCoveredDiseasesByPackageId(packageId);
	}

	@Override
	public DiseaseDetails getDiseaseDetailsById(int discId) {
		return insurancePackageDAO.getDetailsByDiseaseId(discId);
	}

	@Override
	public List<InsurancePackage> getFilteredPackages(String status, int age) {
		return insurancePackageDAO.getFiteredDiseases(status, age);
	}

	@Override
	public List<InsurancePackage> getPackagesByStatus(String status) {
		return insurancePackageDAO.getPackagesByStatus(status);
	}

	@Override
	public List<InsurancePackage> getAllInsurancePackagesByAge(int age) {
		return insurancePackageDAO.getAllInsurancePackagesByAge(age);
	}

	@Override
	public List<DiseaseDetails> getDiseasesByPackageId(int id) {
		return insurancePackageDAO.getDiseasesByPackageId(id);

	}



	@Override
	public List<Categories> getCategoriesByPackageId(int inspId) {
		return insurancePackageDAO.getCategoriesByPackageId(inspId);
	}



	
}