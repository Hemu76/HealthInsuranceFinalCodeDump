package com.insurance.insuranceCompany.contract;

import java.util.ArrayList;

import com.insurance.insuranceCompany.model.InsurancePackage;
import com.insurance.insuranceCompany.model.NetworkHospitals;

public interface NetworkHospitalContract {
	public ArrayList<NetworkHospitals> getAllHopitals();

	public int deleteHospital(int hid);

	public int addHospital(NetworkHospitals hsp);

	public int getHospCount();

	public int editHospital(NetworkHospitals netHsp);

	public ArrayList<InsurancePackage> getRelatedPackages(int hspid);

	public int addPackage(String title, String desc, String status, long rangeStart, long rangeEnd,
			Integer ageLimitStart, Integer ageLimitEnd, int hospid);

	public int deletePackage(int did, int hospid);

	public String updatePackage(String id, String title, String description, String status, String rangeStart,
			String rangeEnd, String ageLimitStrt, String ageLimitEnd);

	public ArrayList<NetworkHospitals> getSearcHospitals(String search);
}
