package com.insurance.Customeroptions.repository;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.insurance.Customeroptions.contracts.InterfaceInsuranceDAO;
import com.insurance.Customeroptions.contracts.InterfaceInsuranceRepository;
import com.insurance.Customeroptions.dao.InsuranceDAO;
import com.insurance.Customeroptions.model.AuthUtils;
import com.insurance.Customeroptions.model.Claim;
import com.insurance.Customeroptions.model.ClaimApplication;
import com.insurance.Customeroptions.model.ClaimBills;
import com.insurance.Customeroptions.model.CustomerData;
import com.insurance.Customeroptions.model.InsuranceApiError;
import com.insurance.Customeroptions.model.InsurancePolicy;
import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.insurance.Customeroptions.model.InsurancePolicySchedule;
import com.insurance.Customeroptions.model.ReUpload;
import com.insurance.Customeroptions.model.Uploads;
import com.insurance.Customeroptions.model.UserData;

import jakarta.servlet.http.HttpSession;

@Repository
public class InsuranceRepository implements InterfaceInsuranceRepository {
	@Autowired
	private InterfaceInsuranceDAO insurancedao;
	private HttpSession session;

	@Autowired
	public InsuranceRepository(InsuranceDAO insurancedao, HttpSession session) {
		this.insurancedao = insurancedao;
		this.session = session;
	}

	// Method to get the count of insurance policies for a customer
	@Override
	public int getInsurancePolicyCountForCustomer(int customerId) {
		return insurancedao.getInsurancePolicyCountForCustomer(customerId);
	}

	// Method to get the count of insurance policies for a family
	@Override
	public int getInsurancePolicyCountForFamily(int customerId) {
		return insurancedao.getInsurancePolicyCountForFamily(customerId);
	}

	// Method to get the count of all active insurance policies
	@Override
	public int getAllActivecount(int customerId) {
		int l1 = insurancedao.getAllActivecountList(customerId);
		return l1;
	}

	// Method to get the sum of insurance policies for a customer
	@Override
	public int getInsurancePolicySum(int customerId) {
		return insurancedao.getInsuranceSum(customerId);
	}

	// Method to get all insurance dates for a customer
	@Override
	public List<Date> getAllInsuranceDates(int customerId) {
		List<Date> l1 = insurancedao.getInsuranceDates(customerId);
		return l1;
	}

	// Method to get all insurance expiration dates for a customer
	@Override
	public List<Date> getAllInsuranceEXPDates(int customerId) {
		List<Date> l2 = insurancedao.getInsuranceEXPDates(customerId);
		return l2;
	}
	public int duplicatePolicy(InsurancePolicy e) throws InsuranceApiError{
		return insurancedao.duplicatePolicyCreation(e);
	}

	// Method to get premium amounts for insurance policies of a customer
	@Override
	public List<Integer> getInsurancePremiumAmount(int customerId) {
		List<Integer> l3 = insurancedao.getInsurancePremium(customerId);
		return l3;
	}

	// Method to get applicant names for insurance policies of a customer
	@Override
	public List<String> getApplicantName(int customerId) {
		List<String> l4 = insurancedao.getApplicantName(customerId);
		return l4;
	}

	// Method to get applicant relations for insurance policies of a customer
	@Override
	public List<String> getApplicantRelation(int customerId) {
		List<String> l5 = insurancedao.getApplicantRelation(customerId);
		return l5;
	}

	// Method to list all policy schedules by ID
	@Override
	public List<InsurancePolicySchedule> ListAllPolicySchedulesById(int id) {
		List<InsurancePolicySchedule> s = insurancedao.getAllScheduleById(id);
		return s;
	}

	// Method to save user data
	@Override
	public Long saveUserData(String userName, String password) {
		long id = insurancedao.saveUserData(userName, password);
		return id;
	}

	// Method to save customer data
	@Override
	public void saveCustomerData(CustomerData customerData) {
		insurancedao.saveCustomerData(customerData);
	}

	// Method to get all customers
	@Override
	public List<CustomerData> getAllCustomers() {
		return insurancedao.getAllCustomersFromDao();
	}

	// Method to get all users
	@Override
	public List<UserData> getAllUsers() {
		return insurancedao.getAllUsersFromDao();
	}

	// Method to upload a file
	@Override
	public String uploadFile(MultipartFile file) {
		return insurancedao.uploadFileToDao(file);
	}

	// Method to get PDF file names
	@Override
	public List<String> getPdfFileNames() {
		return insurancedao.getPdfFileNames();
	}

	// Method to send an email with OTP
	@Override
	public int sendmail(String to_mail) {
		String to = to_mail;
		String subject = "Login OTP";

		int OTP = generateOTP();
		String body = "Your OTP for login : " + OTP;
		sendEmail(to, subject, body);

		return OTP;
	}

	// Method to send an email
	@Override
	public void sendEmail(String to, String subject, String body) {
		String host = "smtp.gmail.com";
		int port = 587;
		String username = "otp.health.insurance@gmail.com";
		String password = "zveu kbpc ivrp fenc";

		// Set properties
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", port);

		// Create session
		Session session = Session.getInstance(props, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			// Create message
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(username));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setSubject(subject);
			message.setText(body);
			Transport.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	// Method to generate a random OTP
	@Override
	public int generateOTP() {
		Random random = new Random();
		int randomNumber = 100000 + random.nextInt(900000);

		return randomNumber;
	}

	// Method to reset the password
	@Override
	public int resetpwd(String email, String pwd, String cnfpwd, Long GessionId) {
		if (pwd.equals(cnfpwd))
			return insurancedao.resetpwd(email, pwd, GessionId);
		else
			return 0;
	}

	// Method to update customer data
	@Override
	public String updateCustomersData(List<CustomerData> updatedCustomerData) {
		insurancedao.updateCustomersData(updatedCustomerData);
		return "updated Successfully";
	}

	// Method to check if the user is valid
	@Override
	public boolean userChecking(String userName, String password, List<UserData> userDataList) {
		for (UserData userData : userDataList) {
			if (userName.equals(userData.getUserName()) && password.equals(userData.getUserPwd())) {
				session.setAttribute("userId", userData.getUserId());
				String key = AuthUtils.generateKey();
				session.setAttribute("key", key);
				userData.getUserId();

				return true;

			}
		}
		return false;
	}

	// Method to get a claim by ID
	@Override
	public Claim getClaimByid(int clamIplcId) {
		return insurancedao.getClaimByid(clamIplcId);
	}

	// Method to add claim bills
	@Override
	public void addClaimBills(ClaimBills bill) {
		insurancedao.addClaimBills(bill);
	}

	// Method to add a claim application
	@Override
	public void addClaimApplication(ClaimApplication application) {
		insurancedao.addClaimApplication(application);
	}

	// Method to add a claim
	@Override
	public int addClaim(int clamIplcId, double claimAmountRequested) {
		return insurancedao.addClaim(clamIplcId, claimAmountRequested);
	}

	// Method to get filtered claims by status
	@Override
	public ArrayList<Claim> getFilteredClaims(String status) {
		return insurancedao.getFilteredClaims(status);
	}

	// Method to get all claims
	@Override
	public List<Integer> getAllClaims(Long userId) {
		return insurancedao.getAllClaims(userId);
	}

	// Method to get family members by policy
	@Override
	public List<String> getFamilyByPolicy(int id) {
		List<InsurancePolicyCoverageMembers> members = insurancedao.getPoliMem();
		List<String> names = new ArrayList<>();
		for (InsurancePolicyCoverageMembers mem : members) {
			if (mem.getIplcId() == id) {
				names.add(mem.getIpcmMemberName());
			}
		}
		return names;
	}

	// Method to get customer ID by user ID
	@Override
	public int getCustIdByUserId(Long userId) {
		return insurancedao.getCustIdByUserId(userId);
	}

	// Method to get all reuploads
	@Override
	public List<ReUpload> getAllReUploads(int id) {
		return insurancedao.getAllReUploads(id);
	}

	// Method to get all uploads
	@Override
	public List<Uploads> getAllUploads(int claimId) {
		return insurancedao.getAllUploads(claimId);
	}

	// Method to add uploads
	@Override
	public void addUploads(Uploads up) {
		insurancedao.addUploads(up);
	}

	// Method to get all claim bills
	@Override
	public List<ClaimBills> getAllClaimBills() {
		return insurancedao.getAllClaimBills();
	}

	// Method to update claim status
	@Override
	public void updateStatus(int claimId) {
		insurancedao.updateStatus(claimId);
	}

	// Method to get upload file by IDF
	@Override
	public Uploads getAllUploadFileById(int id) {
		return insurancedao.getAllUploadFileById(id);
	}

	@Override
	public void storeData(int claimId, MultipartHttpServletRequest request) {
		int index = 1;

		List<ReUpload> list = insurancedao.getAllReUploads(claimId);
		List<Uploads> list2 = insurancedao.getAllUploads(claimId);

		if (list2.size() > 0) {
			index = list2.get(list2.size() - 1).getReUploadId();
		}
		for (ReUpload upload : list) {
			if (upload.getClaimId() == claimId) {
				String name = upload.getName();
				System.out.println(claimId);
				MultipartFile file = request.getFile(name);
				if (file != null) {
					System.out.println(name);

					String uploadDir = "src/main/resources/static/file";
					try {
						Files.createDirectories(Paths.get(uploadDir));
						String fileName = StringUtils.cleanPath(file.getOriginalFilename());
						Path targetLocation = Paths.get(uploadDir).resolve(fileName);
						Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
						targetLocation.toAbsolutePath().toString();
						Uploads up = new Uploads();
						up.setUploadId(index);
						up.setReUploadId(upload.getUploadId());
						up.setClaimId(claimId);
						up.setData(fileName);
						up.setType("file");
						insurancedao.addUploads(up);
						// after uploaded required document then update status
						insurancedao.updateStatus(claimId);
					} catch (IOException ex) {
						ex.printStackTrace();
					}
				} else {
					Uploads up = new Uploads();

					up.setUploadId(index);
					up.setReUploadId(upload.getUploadId());
					up.setClaimId(claimId);

					up.setData(request.getParameter(name));

					up.setType("text");
					insurancedao.addUploads(up);
					insurancedao.updateStatus(claimId);
				}

			}
		}

	}

	@Override
	public boolean checkPolicyIdStatus(int policyId) {

		return insurancedao.checkPolicyIdStatus(policyId);
	}

	@Override
	public Boolean checkRequestedAmount(int pid, double requestedClaimAmount) {
		return insurancedao.checkRequestedAmount(pid, requestedClaimAmount);
	}

	@Override
	public int getInsuranceActiveMember(int customerId) {

		return insurancedao.getInsuranceActiveMember(customerId);
	}

	@Override
	public int getInsuranceActiveCoverage(int customerId) {
		return insurancedao.getInsuranceActiveCoverage(customerId);
	}

	@Override
	public int getRegisterHospitalById(int customerId) {
		// TODO Auto-generated method stub
		return insurancedao.getRegisterHospitalById(customerId);
	}

	@Override
	public int getIndividualHospitalsById(int customerId) {
		// TODO Auto-generated method stub
		return insurancedao.getIndividualHospitalsById(customerId);
	}

	@Override
	public List<Date> getUpcomingInsuranceDate(int customerId) {
		List<Date> l1 = insurancedao.getUpcomingInsuranceDates(customerId);
		return l1;
	}

	@Override
	public List<Date> getLastPaidInsuranceDate(int customerId) {
		List<Date> l1 = insurancedao.getLastPaidInsuranceDates(customerId);
		return l1;
	}

	@Override
	public List<ClaimBills> getClaimBillById(int clamId) {
		List<ClaimBills> l2 = insurancedao.getClaimBillById(clamId);
		return l2;

	}

	@Override
	public List<Uploads> getUploadByClaimId(int clamId) {
		// TODO Auto-generated method stub
		return insurancedao.getUploadByClaimId(clamId);
	}

	@Override
	public List<ReUpload> getReUploadsByClaimId(int clamId) {
		return insurancedao.getReUploadsByClaimId(clamId);
	}

	@Override
	public int getclaimPolicyIdByClaimId(int clamId) {

		return insurancedao.getclaimPolicyIdByClaimId(clamId);
	}

	@Override
	public List<String> getPatientNameByPlocyId(int claimPolicyId) {
		return insurancedao.getPatientNameByPlocyId(claimPolicyId);
	}
}
