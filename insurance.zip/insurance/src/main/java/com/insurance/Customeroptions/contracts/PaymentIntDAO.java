package com.insurance.Customeroptions.contracts;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.insurance.Customeroptions.model.InsurancePolicyPayment;
import com.insurance.Customeroptions.model.NetworkHospitals;

public interface PaymentIntDAO {

	public boolean createPayment(InsurancePolicyPayment ipp);

	List<InsurancePolicyPayment> getAllInsurancePolicyPaymentsList();

  	boolean updateTransactionId(int policyId, String newTransactionId, Date transdate);

	List<InsurancePolicyPayment> getAllFirstPolicy(int policyId);

	List<InsurancePolicyPayment> getAllCustPayments(int custId);

	List<InsurancePolicyCoverageMembers> getAllIPCMList();

	public boolean InsertIPCM(InsurancePolicyCoverageMembers ipcm, int policyid);
	ArrayList<NetworkHospitals> getAllHopitals();
	int getCountNullTransId(int policyId);
	

}
