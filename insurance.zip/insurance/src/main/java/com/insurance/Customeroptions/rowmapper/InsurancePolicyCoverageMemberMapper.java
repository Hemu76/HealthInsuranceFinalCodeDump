package com.insurance.Customeroptions.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;

public class InsurancePolicyCoverageMemberMapper implements RowMapper<InsurancePolicyCoverageMembers> {

	@Override
	public InsurancePolicyCoverageMembers mapRow(ResultSet resultSet, int i) throws SQLException {
		InsurancePolicyCoverageMembers member = new InsurancePolicyCoverageMembers();
		member.setIplcId(resultSet.getInt("iplc_id"));
		member.setIpcmMIndex(resultSet.getInt("ipcm_mindex"));
		member.setIpcmMemberName(resultSet.getString("ipcm_membername"));
		member.setIpcmRelation(resultSet.getString("ipcm_relation"));
		member.setIpcmDob(resultSet.getDate("ipcm_dob"));
		member.setIpcmGender(resultSet.getString("ipcm_gender").charAt(0));
		member.setIpcmHealthHistory(resultSet.getString("ipcm_healthhistory"));
		return member;
	}
}