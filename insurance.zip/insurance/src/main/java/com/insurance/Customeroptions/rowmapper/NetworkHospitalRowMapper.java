package com.insurance.Customeroptions.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.insurance.Customeroptions.model.NetworkHospitals;

public class NetworkHospitalRowMapper implements RowMapper<NetworkHospitals> {

	@Override
	public NetworkHospitals mapRow(ResultSet rs, int rowNum) throws SQLException {
		NetworkHospitals hospital = new NetworkHospitals();
		hospital.setHospId(rs.getInt("hosp_id"));
		hospital.setHospTitle(rs.getString("hosp_title"));
		hospital.setHospLocation(rs.getString("hosp_location"));
		hospital.setHospAddress(rs.getString("hosp_address"));
		hospital.setHospContactNumber(rs.getString("hosp_contactmobile"));
		hospital.setHospPincode(rs.getInt("hosp_pincode"));
		hospital.setHospLuudate(rs.getDate("hosp_luudate"));
		hospital.setHospLuuser(rs.getInt("hosp_luuser"));
		hospital.setGrade(rs.getString("hosp_grade"));
		hospital.setFacilities(rs.getString("hosp_facility"));
		return hospital;
	}
}
