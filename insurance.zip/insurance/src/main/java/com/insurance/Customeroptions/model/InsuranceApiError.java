package com.insurance.Customeroptions.model;

public class InsuranceApiError extends RuntimeException {
	private int exceptionCode;
	private String exceptionMessage;

	public InsuranceApiError(int exceptionCode, String exceptionMessage) {
		super(exceptionMessage);
		this.exceptionCode = exceptionCode;
		this.exceptionMessage = exceptionMessage;
	}

	public int getErrorCode() {
		return exceptionCode;
	}

	public void setErrorCode(int exceptionCode) {
		this.exceptionCode = exceptionCode;
	}

	@Override
	public String getMessage() {
		return exceptionMessage;
	}

	public void setErrorMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	@Override
	public String toString() {
		return "InsuranceApiError [exceptionCode=" + exceptionCode + ", exceptionMessage=" + exceptionMessage + "]";
	}
}
