package com.insurance.Hospital.models;

public class RequestedAmountException extends RuntimeException {
    private String errorCode;
    private String msg;

    public RequestedAmountException(String message, String errorCode) {
        super(message);
        msg = message;
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

	public String getMsg() {
		return msg;
	}
}