package com.insurance.Hospital.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.insurance.Hospital.contracts.ClaimServiceInterface;
import com.insurance.Hospital.models.Claim;
import com.insurance.Hospital.models.ClaimApplication;
import com.insurance.Hospital.models.ClaimBills;
import com.insurance.Hospital.models.NonActivePolicyException;
import com.insurance.Hospital.models.ReUpload;
import com.insurance.Hospital.models.RequestedAmountException;
import com.insurance.Hospital.models.Uploads;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping(value = "/hospital")
public class HospitalClaimController {

	private final Logger logger;

	ClaimServiceInterface claimServiceInterface;
	private HttpSession httpSession;

	@Autowired
	public HospitalClaimController(ClaimServiceInterface claimServiceInterface, Logger hospitalClaimControllerLogger,
			HttpSession httpSession) {
		this.claimServiceInterface = claimServiceInterface;
		this.httpSession = httpSession;
		this.logger = hospitalClaimControllerLogger;
	}

	@GetMapping(value = "/newclaim")
	public String newClaim(Model model) {
		logger.trace("Navigating to the new claim page.");
		return "newclaim";
	}

	@RequestMapping(value = "/claimbills", method = RequestMethod.POST)
	public String claimData(@RequestParam("file[]") MultipartFile[] files,
			@RequestParam("documentTitle") String[] documentNames, @RequestParam("claimAmount") String[] claimAmount,
			Claim claim, ClaimApplication application, Model model) throws IOException {
		int policyId = claim.getClamIplcId();
		// logger.trace("Checking policy status for policy ID: {}", policyId);
		try {
			if (claimServiceInterface.checkPolicyIdStatus(policyId)) {
				throw new NonActivePolicyException("Invalid policy details provided.");
			}
		} catch (NonActivePolicyException e) {
			System.out.println(e);
			return "newclaim";
		}

		if (!claimServiceInterface.checkRequestedAmount(application.getClamIplcId(),
				application.getClaimAmountRequested())) {
			throw new RequestedAmountException("Requested amount cannot be granted", "REQAMT001");
		}

		claimServiceInterface.addClaimApplication(application);
		claimServiceInterface.addClaim(claim.getClamIplcId(), application.getClaimAmountRequested(), "IMS Hospital");

		Claim clm_id = claimServiceInterface.getClaimByid(claim.getClamIplcId());
		int cid = clm_id.getClamId();
		String uploadDir = "src/main/resources/static/file";

		Files.createDirectories(Paths.get(uploadDir));
		int i = 0;
		for (MultipartFile file : files) {
			String fileName = StringUtils.cleanPath(file.getOriginalFilename());
			Path targetLocation = Paths.get(uploadDir).resolve(fileName);
			Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
			String fullPath = targetLocation.toAbsolutePath().toString();
			ClaimBills bill = new ClaimBills();
			bill.setClbl_document_path(fileName);
			bill.setClbl_document_path(documentNames[i]);
			bill.setClbl_claim_amount(Double.parseDouble(claimAmount[i]));
			bill.setClam_id(cid);
			claimServiceInterface.addClaimBills(bill);
		}

		return "newclaim";
	}

	@GetMapping(value = "/getFamilyMembers")
	public ResponseEntity<List<String>> getFamily(@RequestParam("policy") int id, Model model) {

		List<String> members = claimServiceInterface.getFamilyByPolicy(id);
		// logger.info("Retrieved family members for policy ID: {}", id);
		return ResponseEntity.ok(members);

	}

	@GetMapping(value = "/getAllClaims")
	public String getAllClaims(Model model) {

		ArrayList<Claim> li = (ArrayList<Claim>) claimServiceInterface.getAllClaims();
		model.addAttribute("claims", li);
		return "listclaims";

	}

	@PostMapping(value = "/viewClaim")
	public String getClaimById(Model model, @RequestParam("clamId") int clamId) {

		Claim cl = claimServiceInterface.getClaimById(clamId);
		model.addAttribute("claim", cl);
		return "claimview";

	}

	@GetMapping(value = "/getFilteredClaims")
	public String getFilteredClaims(Model model, @RequestParam("status") String status) {
		try {
			ArrayList<Claim> li = (ArrayList<Claim>) claimServiceInterface.getFilteredClaims(status);
			logger.info("Retrieved filtered claims by status {}. Total claims: {}", status, li.size());
			model.addAttribute("claims", li);
			return "listclaims";
		} catch (Exception ex) {
			logger.error("Error occurred while retrieving filtered claims by status {}: {}", status, ex.getMessage());
			model.addAttribute("errorMessage", "An error occurred while processing your request.");
			return "error";
		}
	}

	@RequestMapping(value = "/excel", method = RequestMethod.POST)
	public void downloadExcel(@RequestParam("selectedStatus") String status, HttpServletResponse response)
			throws IOException {
		try {
			claimServiceInterface.downloadExcel(status, response);
			logger.info("Downloaded Excel file for claims with status: {}", status);
		} catch (Exception ex) {
			logger.error("Error occurred while downloading Excel file for claims with status {}: {}", status,
					ex.getMessage());
			// Handle the exception and possibly return an error response to the client.
		}
	}

	@GetMapping(value = "/getrequired")
	public String getRequiredUploads(@RequestParam("claimid") int id, Model model) {

		if (!claimServiceInterface.getAllReUploads(id).isEmpty()) {
			model.addAttribute("reupload", claimServiceInterface.getAllReUploads(id));
			model.addAttribute("claimid", id);
			return "updates";
		} else {
			model.addAttribute("claimid", id);
			return "status";
		}

	}

	@PostMapping(value = "/adduploads")
	public String addUploads(@RequestParam("claimid") String id, MultipartHttpServletRequest request, Model model)
			throws IOException {

		System.out.println("start");
		int claimId = Integer.parseInt(id);
		int index = 1;
		List<ReUpload> list = claimServiceInterface.getAllReUploads(claimId);
		List<Uploads> list2 = claimServiceInterface.getAllUploads(claimId);

		if (list2.size() > 0) {
			index = list2.get(list2.size() - 1).getReUploadId();
		}

		for (ReUpload upload : list) {
			if (upload.getClaimId() == claimId) {
				String name = upload.getName();
				MultipartFile file = request.getFile(name);
				if (file != null) {
					String uploadDir = "src/main/resources/static/file";
					Files.createDirectories(Paths.get(uploadDir));
					String fileName = StringUtils.cleanPath(file.getOriginalFilename());
					Path targetLocation = Paths.get(uploadDir).resolve(fileName);
					Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
					String fullPath = targetLocation.toAbsolutePath().toString();
					Uploads up = new Uploads();
					up.setUploadId(index);
					up.setReUploadId(upload.getUploadId());
					up.setClaimId(claimId);
					up.setData(fileName);
					up.setType("file");
					claimServiceInterface.addUploads(up);
					claimServiceInterface.updateReUploads(upload.getUploadId(), claimId);
				} else {
					Uploads up = new Uploads();
					up.setUploadId(index);
					up.setReUploadId(upload.getUploadId());
					up.setClaimId(claimId);
					up.setData(request.getParameter(name));
					up.setType("text");
					claimServiceInterface.addUploads(up);
					claimServiceInterface.updateReUploads(upload.getUploadId(), claimId);
				}
			}
		}
		System.out.println("end");
		Claim cl = claimServiceInterface.getClaimById(Integer.parseInt(id));
		model.addAttribute("claim", cl);
		return "claimview";

	}
}
