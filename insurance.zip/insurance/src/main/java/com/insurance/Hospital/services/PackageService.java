package com.insurance.Hospital.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.insurance.Hospital.contracts.PackageDaoInterface;
import com.insurance.Hospital.contracts.PackageServiceInterface;
import com.insurance.Hospital.models.DiseaseDetails;
import com.insurance.Hospital.models.InsurancePackage;
import com.insurance.Hospital.models.InsurancePackageCoveredDisease;

@Service
public class PackageService implements PackageServiceInterface{
	
	@Autowired
	PackageDaoInterface packageDaoInterface;

	@Override
	public List<InsurancePackage> getAllInsurancePackages() {

		return packageDaoInterface.getAllInsurancePackages();
	}

	@Override
	public List<InsurancePackageCoveredDisease> getCoveredDiseasesByPackageId(int packageId) {

		return packageDaoInterface.getCoveredDiseasesByPackageId(packageId);
	}


	@Override
	public List<InsurancePackage> getFiteredDiseases(String status, int age) {

		return packageDaoInterface.getFiteredDiseases(status, age);
	}

	@Override
	public List<InsurancePackage> getPackagesByStatus(String status) {

		return packageDaoInterface.getPackagesByStatus(status);
	}

	@Override
	public List<InsurancePackage> getAllInsurancePackagesByAge(int age) {

		return packageDaoInterface.getAllInsurancePackagesByAge(age);
	}

	@Override
	public List<DiseaseDetails> getDiseasesByPackageId(int inspId) {

		return packageDaoInterface.getDiseasesByPackageId(inspId);
	}

}
