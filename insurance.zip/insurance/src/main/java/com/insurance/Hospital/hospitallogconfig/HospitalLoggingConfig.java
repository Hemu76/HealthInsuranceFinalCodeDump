package com.insurance.Hospital.hospitallogconfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.insurance.Hospital.controller.DashboardController;
import com.insurance.Hospital.controller.HospitalClaimController;
import com.insurance.Hospital.controller.HospitalLoginController;
import com.insurance.Hospital.controller.HospitalPaymentController;
import com.insurance.Hospital.controller.PackageController;
import com.insurance.Hospital.controller.ProceduresController;

@Configuration
public class HospitalLoggingConfig {

	@Bean
	public Logger dashboardControllerLogger() {
		return LoggerFactory.getLogger(DashboardController.class);
	}

	@Bean
	public Logger hospitalClaimControllerLogger() {
		return LoggerFactory.getLogger(HospitalClaimController.class);
	}

	@Bean
	public Logger hospitalLoginControllerLogger() {
		return LoggerFactory.getLogger(HospitalLoginController.class);
	}

	@Bean
	public Logger hospitalPaymentControllerLogger() {
		return LoggerFactory.getLogger(HospitalPaymentController.class);
	}

	@Bean
	public Logger packageControllerLogger() {
		return LoggerFactory.getLogger(PackageController.class);
	}

	@Bean
	public Logger proceduresControllerLogger() {
		return LoggerFactory.getLogger(ProceduresController.class);
	}

}
