$(document).ready(function() {
  // Focus on the first OTP input box
  $("#digit1").focus();

  // Listen for input in each OTP input box
  $(".otp-input").on("input", function() {
    var currentBox = $(this);
    var maxLength = parseInt(currentBox.attr("maxlength"));
    var currentValue = currentBox.val();

    if (currentValue.length === maxLength) {
      // Move focus to the next OTP input box if available
      currentBox.next(".otp-input").focus();
    } else if (currentValue.length === 0) {
      // Handle backspace to move to the previous OTP input box
      currentBox.prev(".otp-input").focus();
    }
  });
  
  $.ajax({
  	url: "/customer/email",
  	data: { "to" : localStorage.getItem("userEmail") },
  	success: function(response){
  		console.log(response);
  	},
  	error: function(error){
  		console.log(error);
  	}
  });

  // Verify OTP Button Click Event
  $("#verify-otp-button").on("click", function() {
  	var otpValue = "";
      	$(".otp-input").each(function() {
        	otpValue += $(this).val();
      	});
	$.ajax({
  			url: "/customer/validateOTP",
  			method: "POST",
  			data: { "otp" :  otpValue},
  			success: function(otpResponse){
  				console.log(otpResponse);
  				switch(otpResponse[0]){
  					case "success" : {
  						window.location.href = "home.html";
  						localStorage.setItem('customerId',otpResponse[2]);
  						break;
  					}
  					case "invalid" : {
  						alert("invalid otp");
  						break;
  					}
  					case "expired" : {
  						alert("otp expired");
  						break;
  					}
  					default: {} 
  				}
  			},
  			error: function(error){
  				console.log(error);
  			}
  		});
  });
});