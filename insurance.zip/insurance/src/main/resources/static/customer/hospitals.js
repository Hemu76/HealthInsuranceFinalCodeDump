$(document).ready(function() {
	const citySelector = $('#citySelector');
	const mapContainer = $('#map');
	const noHospitalsMessage = $('.no-hospitals-message');
	let map;

	const cityData = {
		delhi: [
			{ name: 'Hospital A', lat: 28.6139, lng: 77.2090 },
			{ name: 'Hospital B', lat: 28.7041, lng: 77.1025 },
			{ name: 'Hospital C', lat: 28.6505, lng: 77.2302 },
			{ name: 'Hospital D', lat: 28.7049, lng: 77.1060 },
			{ name: 'Hospital E', lat: 28.6139, lng: 77.2090 },
			{ name: 'Hospital F', lat: 28.6953, lng: 77.1118 },
		],
		mumbai: [
			{ name: 'Hospital X', lat: 19.0760, lng: 72.8777 },
			{ name: 'Hospital Y', lat: 19.0762, lng: 72.8656 },
			{ name: 'Hospital Z', lat: 19.0763, lng: 72.8820 },
			{ name: 'Hospital P', lat: 19.0764, lng: 72.8784 },
			{ name: 'Hospital Q', lat: 19.0766, lng: 72.8657 },
			{ name: 'Hospital R', lat: 19.0768, lng: 72.8764 },
		],
		chennai: [
			{ name: 'Hospital 1', lat: 13.0827, lng: 80.2707 },
			{ name: 'Hospital 2', lat: 13.0836, lng: 80.2705 },
			{ name: 'Hospital 3', lat: 13.0832, lng: 80.2707 },
			{ name: 'Hospital 4', lat: 13.0839, lng: 80.2710 },
			{ name: 'Hospital 5', lat: 13.0828, lng: 80.2715 },
			{ name: 'Hospital 6', lat: 13.0835, lng: 80.2706 },
		],
		kolkata: [
			{ name: 'Hospital I', lat: 22.5726, lng: 88.3639 },
			{ name: 'Hospital II', lat: 22.5729, lng: 88.3641 },
			{ name: 'Hospital III', lat: 22.5731, lng: 88.3638 },
			{ name: 'Hospital IV', lat: 22.5727, lng: 88.3642 },
			{ name: 'Hospital V', lat: 22.5732, lng: 88.3637 },
			{ name: 'Hospital VI', lat: 22.5728, lng: 88.3636 },
		],
		bangalore: [
			{ name: 'Hospital Alpha', lat: 12.9716, lng: 77.5946 },
			{ name: 'Hospital Beta', lat: 12.9719, lng: 77.5945 },
			{ name: 'Hospital Gamma', lat: 12.9721, lng: 77.5948 },
			{ name: 'Hospital Delta', lat: 12.9725, lng: 77.5943 },
			{ name: 'Hospital Epsilon', lat: 12.9717, lng: 77.5942 },
			{ name: 'Hospital Zeta', lat: 12.9720, lng: 77.5947 },
		],
	};

	citySelector.change(function() {
		const selectedCity = citySelector.val();
		const hospitals = cityData[selectedCity] || [];

		// Call a function to update the map with the selected city's hospitals and zoom in
		updateMap(hospitals);
	});

	function updateMap(hospitals) {
		// Initialize the map if it hasn't been created yet
		if (!map) {
			map = L.map('map').setView([20.5937, 78.9629], 6); // Default view for India with adjusted zoom
			L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
				attribution: '© OpenStreetMap contributors'
			}).addTo(map);
		}

		// Remove previous markers
		map.eachLayer(layer => {
			if (layer instanceof L.Marker) {
				map.removeLayer(layer);
			}
		});

		// Hide the no-hospitals message by default
		noHospitalsMessage.hide();

		if (hospitals.length === 0) {
			// If there are no hospitals, show the no-hospitals message and make the map a bit opaque
			noHospitalsMessage.show();
			map.getContainer().style.opacity = '0.5';
		} else {
			// Add markers for each hospital
			hospitals.forEach(hospital => {
				L.marker([hospital.lat, hospital.lng])
					.bindPopup(hospital.name)
					.addTo(map);
			});

			// Zoom to the bounds of the markers with a bit more padding
			const bounds = new L.LatLngBounds(hospitals.map(hospital => [hospital.lat, hospital.lng]));
			map.fitBounds(bounds.pad(0.1));

			// Make the map fully visible
			map.getContainer().style.opacity = '1';
		}
	}

	// Trigger change event to display the hospitals of the first city when the page loads
	citySelector.change();
});
