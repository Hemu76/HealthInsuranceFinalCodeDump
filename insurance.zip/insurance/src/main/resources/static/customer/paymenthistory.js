$.ajax({
	url: "ippsts/2",
	method: "GET",
	success: function(data) {
		console.log(data);
		const $cardContainer = $('#card-container');
		data = data.filter(item => item.transDate !== null);


		// Function to filter and display cards based on the search input
		function filterCards(searchText) {
			

			data.forEach(item => {
				if (item.transDate.toLowerCase().includes(searchText.toLowerCase())) {

					const cardItem = `
    				<div class="card">
        			<p><b>PolicyID</b> : ${item.policyId} <br><br>  <b>Amount</b> : ${item.amount} <br><br> <b>Transaction Date</b> : ${item.transDate} </p>
    				</div>`;

					$cardContainer.append(cardItem);
					// Initial display of all cards
					filterCards("");

					// Add an event listener to the search input
					$('#search-input').on('input', function() {
						const searchText = $(this).val();
						filterCards(searchText);
					});
				}
			});
		}

	}
});


